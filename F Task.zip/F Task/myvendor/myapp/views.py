#from django.shortcuts import render
from rest_framework import status
from rest_framework import viewsets
from django.db.models import Count
from django.http import JsonResponse
from django.views import View
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import generics
from .models import Vendor, PurchaseOrder, HistoricalPerformance
from .serializers import VendorSerializer, PurchaseOrderSerializer, HistoricalPerformanceSerializer

class VendorViewSet(viewsets.ModelViewSet):
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer 

class PurchaseOrderViewSet(viewsets.ModelViewSet):
    queryset = PurchaseOrder.objects.all()
    serializer_class = PurchaseOrderSerializer

class HistoricalPerformanceViewSet(viewsets.ModelViewSet):
    queryset = HistoricalPerformance.objects.all()
    serializer_class = HistoricalPerformanceSerializer

# Historical Performance API views
@api_view(['GET', 'POST'])
def historical_performance_list(request):
    if request.method == 'GET':
        performances = HistoricalPerformance.objects.all()
        serializer = HistoricalPerformanceSerializer(performances, many = True)
        return Response(serializer.data)
    elif request.method == 'POST':
        serializer = HistoricalPerformanceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['GET', 'PUT', 'DELETE'])
def historical_performance_details(request, pk):
    try:
        performance = HistoricalPerformance.objects.get(pk=pk)
    except HistoricalPerformance.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = HistoricalPerformanceSerializer(performance)
        return Response(serializer.data)
    elif request.method == 'PUT':
        serializer = HistoricalPerformanceSerializer(performance, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        performance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



#Vendor API views
@api_view(['POST'])
def create_vendor(request):
    if request.method == 'POST':
        serializer = VendorSerializer(data=request.data)
        if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            print(serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def list_vendors(request):
    vendors = Vendor.objects.all()
    serializer = VendorSerializer(vendors, many=True)
    return Response(serializer.data)

@api_view(['GET', 'PUT', 'DELETE'])
def vendor_detail(request):
    try :
        vendor = Vendor.objects.get(pk=vendor_id)
    except Vendor.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = VendorSerializer(vendor)
        return Response(serializer.data)
    elif request.method == 'PUT':
        serializer = VendorSerializer(vendor, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    elif request.method == 'DELETE':
        vendor.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



# Purchase Order API Views

@api_view(['POST'])
def create_purchase_order(request):
    serializer = PurchaseOrderSerializer(data = request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def list_purchase_orders(request):
    if 'vendor_id' in request.GET:
        vendor_id = request.GET['vendor_id']
        purchase_orders = PurchaseOrder.objects.filter(vendor_id=vendor_id)
    else:
        purchase_orders = PurchaseOrder.objects.all()

    serializer = PurchaseOrderSerializer(purchase_orders, many=True)
    return Response(serializer.data)

@api_view(['GET', 'PUT', 'DELETE'])
def purchase_order_detail(request, po_id):
    try:
        purchase_order = PurchaseOrder.objects.get(pk=po_id)
    except PurchaseOrder.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = PurchaseOrder(purchase_order)
        return Response(serializer.data)
    elif request.method == 'PUT':
        serializer = PurchaseOrderSerializer(purchase_order, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    elif request.method == 'DELETE':
        purchase_order.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    
    
#vendor Performance API View
@api_view(['GET'])
def vendor_performance(request, vendor_id):
    try:
        vendor = Vendor.objects.get(pk=vendor_id)
    except Vendor.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    performance_data={
        'on_time_delivery_rate' : vendor.on_time_delivery_rate,
        'quality_rating': vendor.quality_rating,
        'response_time':vendor.response_time,
        'fulfilment_rate': vendor.fulfilment_rate
    }
    return Response(performance_data)


class VendorPerformanceView(View):
    def get(self, request, vendor_id):
        completed_pos = PurchaseOrder.objects.filter(vendor_id=vendor_id, status='completed')
        total_completed_pos = completed_pos.count()
        on_time_deliveries = completed_pos.filter(completion_date__lte = models.F('delivery_date')).count()
        on_time_delivery_rate = on_time_deliveries / total_completed_pos if total_completed_pos != 0 else 0

        avg_quality_rating = PurchaseOrder.objects.filter(vendor_id=vendor_id, status='completed').aggregate(avg_rating=models.Avg('quality_rating'))['avg_rating']
        return JsonResponse({'on_time_delivery_rate': on_time_delivery_rate, 'avg_quality_rating': avg_quality_rating})
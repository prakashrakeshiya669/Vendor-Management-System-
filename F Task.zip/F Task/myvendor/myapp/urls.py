from django.urls import path,include
from rest_framework.routers import DefaultRouter
from .views import VendorViewSet , PurchaseOrderViewSet, HistoricalPerformanceViewSet, VendorPerformanceView
from . import views

router = DefaultRouter()
router.register(r'api/vendors', VendorViewSet)
router.register('api/purchase_orders', PurchaseOrderViewSet)
router.register('api/historical_performance', HistoricalPerformanceViewSet)
urlpatterns = [
    path('', include(router.urls)),
    # Vendor API Endpoints
    path('api/vendors1/', views.list_vendors),
    path('api/vendors/<int:vendor_id>/', views.vendor_detail),
    path('api/vendors/<int:vendor_id>/performance/', views.vendor_performance),
    path('api/vendors/<int:pk>/performane/', VendorPerformanceView.as_view(), name='vendor_performance'),


    #Purchase Order API Endpoints
    path('api/purchase_orders_list/', views.list_purchase_orders),
    path('api/purchase_orders/<int:po_id>/', views.purchase_order_detail),


    #HistoricalPerformance
    path('api/historical_performance/', views.historical_performance_list),
    path('api/historical_performance/<int:pk>/', views.historical_performance_details)
 
]
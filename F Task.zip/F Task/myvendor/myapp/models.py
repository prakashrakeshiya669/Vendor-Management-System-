from django.db import models
from django.utils import timezone

# Create your models here.
class Vendor(models.Model):
    name = models.CharField(max_length=300)
    contact_details = models.CharField(max_length=300)
    address = models.TextField()
    vendor_code = models.CharField(max_length=50, unique=True)

    #performace Metrics
    on_time_delivery_rate = models.FloatField(default=0.0)
    quality_rating = models.FloatField(default=0.0)
    response_time = models.FloatField(default=0.0)
    fulfilment_rate = models.FloatField(default=0.0)

    def __str__(self):
        return self.name


class PurchaseOrder(models.Model):
    po_number = models.CharField(max_length=50, unique=True)
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE)
    order_date = models.DateField()
    items = models.TextField()
    quantity = models.PositiveIntegerField()
    status = models.CharField(max_length=50) # 'completed', 'pending', etc
    delivery_date = models.DateField()
    completion_date = models.DateField(null=True, blank=True)
    quality_rating = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return self.po_number

    

class HistoricalPerformance(models.Model):
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE)
    date = models.DateTimeField(default=timezone.now)
    on_time_delivery_rate = models.FloatField()
    quality_rating_avg = models.FloatField()
    average_response_time = models.FloatField()
    fulfilment_rate = models.FloatField()

    def __str__(self):
        return f"{self.vendor.name}  - {self.date}"



    